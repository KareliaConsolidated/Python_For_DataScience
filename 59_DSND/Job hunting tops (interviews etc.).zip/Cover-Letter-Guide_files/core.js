function DisplayNone(A){document.getElementById(A).style.display="none";}function DisplayBlock(A){document.getElementById(A).style.display="block";
}function collapse(A){var B=document.getElementById(A);if(B.style.display=="none"){B.style.display="block";
}else{B.style.display="none";}}function BookmarkPage(){var A=navigator.userAgent;
if(A.indexOf("MSIE")>-1){if(parseInt(navigator.appVersion)>=4){window.external.AddFavorite(window.location.href,document.title);
}}else{if(A.indexOf("Firefox")>-1){window.sidebar.addPanel(document.title,window.location.href,"");
}else{var B="resizable,toolbar=no,location=no,scrollbars=no,width=400,height=400,left=0,top=0";
newWindow=window.open("/Help/Bookmarking.aspx","newWin",B);newWindow.focus();}}}var newWindow=null;
function closeWin(){if(newWindow!=null){if(!newWindow.closed){newWindow.close();}}}function popUpWin(B,C,A){closeWin();
var D="";D="resizable,toolbar=no,location=no,scrollbars=1,width="+C+",height="+A+",left=0,top=0";
newWindow=window.open(B,"newWin",D);if(newWindow!=null){newWindow.focus();}}function HideSurveyLink(){document.getElementById("SurveyLink").innerHTML="";
}function QueryString(A){hu=window.location.search.substring(1);gy=hu.split("&");
for(i=0;i<gy.length;i++){ft=gy[i].split("=");if(ft[0]==A){return ft[1];}}}