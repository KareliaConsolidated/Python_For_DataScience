document.write('');

var ACE_AR = {site: '774166', size: '468060', Region: '2'};

document.write('\n<script type=\'text/javascript\' SRC=\'http://uac.advertising.com/wrapper/aceUAC.js\'><\/script>');document.write('');
